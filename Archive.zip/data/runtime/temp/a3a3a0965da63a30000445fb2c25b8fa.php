<?php /*a:1:{s:47:"/www/wwwroot/videoapi/app/index/view/index.html";i:1564044710;}*/ ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset=utf-8>
  <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
  <meta name=apple-mobile-web-app-status-bar-style content=default>
  <meta name=theme-color content=#2196f3>
  <meta name=format-detection content="telephone=no">
  <meta name=msapplication-tap-highlight content=no>
  <title>家校互通</title>
  <script src=/static/eleditor/jquery.min.js> </script> <script src=/static/eleditor/webuploader.min.js> </script>
    <script src=http://res.wx.qq.com/open/js/jweixin-1.4.0.js> </script> <link href=app.css?v=7
    rel=stylesheet></head><body><div id=app></div><script type=text/javascript src=app.js?v=13></script>
  </body>

</html>