<?php /*a:2:{s:74:"/www/wwwroot/videoapi/public/themes/admin_simpleboot3/admin/video/add.html";i:1566994511;s:72:"/www/wwwroot/videoapi/public/themes/admin_simpleboot3/public/header.html";i:1566833621;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link rel="stylesheet" href="/themes/admin_simpleboot3/public/assets/css/admin.css?v=<?php echo time() ?>">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo app('request')->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
<script src="/static/js/layui/layui.js"></script>
<link rel="stylesheet" href="/static/js/layui/css/layui.css">
</head>

<body>

  <div class="wrap col-md-8">
    <h3>添加视频</h3>
    <br>
    <form class="layui-form" lay-filter="main">
      <div class="layui-form-item">
        <label class="layui-form-label">标题</label>
        <div class="layui-input-block">
          <input type="text" name="title" required lay-verify="required" placeholder="请输入标题" autocomplete="off"
            class="layui-input">
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">分类</label>
        <div class="layui-input-block">
          <select name="category" lay-verify="required">
            <option value="">选择分类</option>
            <?php echo $categories; ?>
          </select>
        </div>
      </div>
      <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">视频缩略图</label>
        <div class="layui-input-block">
          <input id="photo-1" type="hidden" value="" name="thumbnail">
          <img id="photo-1-preview" style="max-width:60px">
          <a class="layui-btn layui-btn-sm layui-btn-primary"
            href="javascript:uploadOneImage('图片上传','#photo-1');">上传</a>
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">免费视频</label>
        <div class="layui-input-block">
          <input type="checkbox" value="1" name="is_free" lay-skin="switch">
        </div>
      </div>
      <div class="layui-form-item">
        <label class="layui-form-label">视频类型</label>
        <div class="layui-input-block">
          <input type="checkbox" value="1" id="is_local" lay-text="本地上传|远程链接" lay-filter="localVideo" name="is_local"
            lay-skin="switch">
        </div>
      </div>
      <div class="layui-form-item remote-video">
        <label class="layui-form-label">视频链接</label>
        <div class="layui-input-block">
          <input type="text" name="video_url" placeholder="请输入视频链接" autocomplete="off" class="layui-input">
        </div>
      </div>
      <div class="layui-form-item layui-form-text local-video" style="display:none;">
        <label class="layui-form-label">视频上传</label>
        <div class="layui-input-block">
          <input id="file-1" type="hidden" value="" name="local_video_url">
          <a class="layui-btn layui-btn-sm layui-btn-primary"
            href="javascript:uploadOne('视频上传','#file-1','video');">上传</a>
          <input id="file-1-name" type="text" name="file_name" title="视频">
        </div>
      </div>
      <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">视频简介</label>
        <div class="layui-input-block">
          <textarea name="description" placeholder="请输入内容" class="layui-textarea"></textarea>
        </div>
      </div>
      <div class="layui-form-item">
        <div class="layui-input-block">
          <button class="layui-btn" lay-submit lay-filter="*">提交</button>
          <a href="/admin/video/" class="layui-btn layui-btn-primary">返回</a>
        </div>
      </div>
  </div>
  </form>



  </div>

  <script src="/static/js/admin.js"></script>
  <script>
    $('.save').on('click', function () {
      parent.layer.closeAll()
    })

    layui.use('form', function () {
      var form = layui.form;

      form.verify({
        url: function (value, item) {
          if (!new RegExp("(https?|ftp|file)://[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]").test(value)) {
            var is_local = $('#is_local').val() == 1;
            if (!is_local) {
              return '请输入正规链接'
            }

          }
        }
      });

      form.on('switch(localVideo)', function (data) {
        var checked = data.elem.checked;
        if (checked) {
          $('.remote-video').hide();
          $('input[name="video_url"]').val('');
          $('input[name="file_name"]').val('');
          $('.local-video').show();
        } else {
          $('.local-video').hide();
          $('input[name="local_video_url"]').val('');
          $('.remote-video').show();
        }
      });
      form.on('submit(*)', function (data) {
        $.ajax({
          type: "POST",
          url: "/admin/video/addPost",
          data: data.field,
          dataType: "json",
          success: function (response) {
            if (response.code == 1) {
              window.location.href = "/admin/video/"
            } else {
              layer.msg(response.msg)
            }
          }
        });
        return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
      });
    });
  </script>
</body>

</html>