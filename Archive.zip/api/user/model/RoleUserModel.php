<?php
namespace api\user\model;

use think\Model;

class RoleUserModel extends Model
{

}
