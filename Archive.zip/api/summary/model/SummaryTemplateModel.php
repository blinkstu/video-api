<?php
namespace api\summary\model;

use think\Model;

class SummaryTemplateModel extends Model{
  
}