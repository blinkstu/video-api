<?php

namespace api\summary\model;

use think\Model;

class UserModel extends Model{
  
}