<?php
use think\facade\Route;

Route::rule('/uploader', '/api/support/public/upload', 'POST'); //获取收藏列表