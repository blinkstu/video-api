<?php 

namespace api\user\controller;

use cmf\controller\RestBaseController;
use think\Db;
use think\facade\Validate;

class PublicController extends RestBaseController
{
}