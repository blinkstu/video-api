<?php

namespace api\video\model;

use think\Model;

class CategoryModel extends Model
{
  protected $autoWriteTimestamp = false;
}
