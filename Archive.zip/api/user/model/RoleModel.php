<?php
namespace api\user\model;

use think\Model;

class RoleModel extends Model
{
}
